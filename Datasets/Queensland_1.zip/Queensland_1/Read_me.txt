Please Note:
All data files use a pipe character | as the delimiter.
The first line of each file contains a header record with column/field names.
Microsoft Excel has a limit to the number of rows of data it can store so will not be suitable for files with a large number of rows such as WATER_LEVELS.


To import the extracted data into Microsoft Excel 2003:

1. Open the zip file and export the data files (there should be 11) to your disk drive.
2. Open a new Excel spreadsheet.
3. Click on 'Data' --> 'Import External Data' --> 'Import Data'.
4. Navigate to where you saved the data files and double click on one of them. The 'Text Import Wizard' will appear.
5. For step 1 of the wizard make sure that 'Delimited' is selected then click on 'Next'.
6. For step 2 of the wizard place a tick in the 'Other' box. Then place a vertical line in the box next to it. To do this hold the 'Shift' key and the 'Pipe' key at the same time (the pipe key is the key above the 'Enter' key).
7. Then click on 'Finish' and then click on the 'Ok' button. Your data should now be in Excel.

Repeat steps 3 to 8 for each txt file.

To import the extracted data into Microsoft Excel 2010:

1. Open the zip file and export the data files (there should be 11) to your disk drive.
2. Open a new Excel spreadsheet.
3. Click on the 'Data' tab then on the button called 'From Text'.
4. Navigate to where you saved the data files and double click on one of them. The 'Text Import Wizard' will appear.
5. For step 1 of the wizard make sure that 'Delimited' is selected then click on 'Next'.
6. For step 2 of the wizard place a tick in the 'Other' box. Then place a vertical line in the box next to it. To do this hold the 'Shift' key and the 'Pipe' key at the same time (the pipe key is the key above the 'Enter' key).  Set the Text qualifier to '{none}'.
7. Then click on 'Finish' and then click on the 'Ok' button. Your data should now be in Excel.

Repeat steps 3 to 8 for each txt file.



To import the extracted data into Microsoft Access 2003:

1. Open the zip file and export the data files (there should be 11) to your disk drive.
2. Open a new Access database.
3. Click on 'File' --> 'Get External Data' --> 'Import...'
4. Navigate to where you saved the data files. Change the 'Files of type' drop down box to 'Text Files' then double click on one of them.
5. The 'Text Import Wizard' will appear.
6. Choose 'Delimited' at the top then click 'Next'.
7. Choose the 'Other' box. Then place a vertical line in the box next to it. To do this hold the 'Shift' key and the 'Pipe' key at the same time (the pipe key is the key above the 'Enter' key).  Place a tick in the 'First Row Contains Field Names' box.  Choose " from the 'Text Qualifier' drop down box.  Then click 'Next'.
8. Leave as 'In a New Table' then click 'Next'.
9. Click 'Next'.
10. Select 'No primary key' then click 'Next'.
11. Type in a name for the table or you can leave it as the same as the txt file.  Click 'Finish'.
12. To aid in querying you will need to set up primary keys and the table relationships
13. To set up primary keys select a table then click on the 'Design' button (just above the list of tables). The primary key's are different for each table please select the correct field names for a table using the guide below:

REGISTRATION             - RN
CASING                   - RN, PIPE, RDATE, REC
STRATA_LOG               - RN, REC
AQUIFER                  - RN, REC
LITHOLOGIES              - RN, REC, SEQ
STRATIGRAPHY             - RN, REC, DATA_OWNER
ELEVATIONS               - RN, PIPE, RDATE
WATER_LEVELS             - RN, PIPE, RDATE
WATER_ANALYSIS           - RN, PIPE, RDATE, REC
WATER_QUALITY_FIELD      - RN, PIPE, RDATE
MULTIPLE_CONDUCTIVITY    - RN, PIPE, RDATE, DEPTH
SPECIAL_ANALYSIS_SAMPLE  - RN, PIPE, SAMPNUM, BOTTLE
SPECIAL_ANALYSIS_RESULTS - RN, PIPE, SAMPNUM, BOTTLE, VARIABLE_NO
FACILITY_ROLES           - RN, FACILITY_ROLE
PUMP_TEST_DESIGN         - RN, PIPE, RDATE, REC
PUMP_TEST_READINGS       - RN, PIPE, RDATE, REC, TIME, TEST_TYPE
BORE_CONDITION           - RN, RDATE
FLOW_IRREGULARITIES      - RN, RDATE, IRREGULARITY
PRECIPITATES             - RN, RDATE, PRECIPITATES
WIRELINE_LOGS            - RN, RDATE, LOG_TYPE, RUN_NUM
WATER_QUALITY_VARIABLES  - VARIABLE_NO

Once selected click on the button with a key symbol.  Small keys should appear beside the field names.
14. Now all of the primary keys are set up go to 'Tools' --> 'Relationships...'
15. Click 'Add' for each of the tables then 'Close'.  Note: if the 'Show Table' window doesn't appear click on the button with a "small yellow plus to the left of a table" just under the 'Window' menu option.
16. Arrange the tables so that registration is in the middle with all others around it.  click on RN in registration and drag to RN in another table.  In the window that pop's up check the 'Enforce Referential Integrity' box then click 'Ok'.  A line should now appear with a 1 near registration and infinity near the other table.  Repeat this for each table.



To import the extracted data into Microsoft Access 2010:

1. Open the zip file and export the data files (there should be 11) to your disk drive.
2. Open a new Access database.
3. Click on the External Data tab then on 'Text File' under the Import & Link section.  Note: NOT the Export Text File button!
4. Click on Browse and navigate to where you saved the data files select one then click Open.
5.  Make sure that the 'Import the source data into a new table in the current database' is selected then click Ok.
6. The 'Text Import Wizard' will appear. Choose 'Delimited' at the top then click 'Next'.
7. Choose the 'Other' box. Then place a vertical line in the box next to it. To do this hold the 'Shift' key and the 'Pipe' key at the same time (the pipe key is the key above the 'Enter' key).  Place a tick in the 'First Row Contains Field Names' box.  Choose " from the 'Text Qualifier' drop down box.  Then click 'Next'.
8. Don't worry about the settings here click 'Next'.
9. Select 'No primary key' then click 'Next'.
10. Type in a name for the table or you can leave it as the same as the txt file.  Click 'Finish'.
11. Don't worry about saving the import as each file is different, click 'Close'.
12. Repeat these for the other data files.

13. To aid in querying you will need to set up primary keys and the table relationships
14. Click on the Home tab and on the far left select the 'View' and choose 'Design view'
15. The primary keys are different for each table please select the correct field names for a table using the guide below:

REGISTRATION             - RN
CASING                   - RN, PIPE, RDATE, REC
STRATA_LOG               - RN, REC
AQUIFER                  - RN, REC
LITHOLOGIES              - RN, REC, SEQ
STRATIGRAPHY             - RN, REC, DATA_OWNER
ELEVATIONS               - RN, PIPE, RDATE
WATER_LEVELS             - RN, PIPE, RDATE
WATER_ANALYSIS           - RN, PIPE, RDATE, REC
WATER_QUALITY_FIELD      - RN, PIPE, RDATE
MULTIPLE_CONDUCTIVITY    - RN, PIPE, RDATE, DEPTH
SPECIAL_ANALYSIS_SAMPLE  - RN, PIPE, SAMPNUM, BOTTLE
SPECIAL_ANALYSIS_RESULTS - RN, PIPE, SAMPNUM, BOTTLE, VARIABLE_NO
FACILITY_ROLES           - RN, FACILITY_ROLE
PUMP_TEST_DESIGN         - RN, PIPE, RDATE, REC
PUMP_TEST_READINGS       - RN, PIPE, RDATE, REC, TIME, TEST_TYPE
BORE_CONDITION           - RN, RDATE
FLOW_IRREGULARITIES      - RN, RDATE, IRREGULARITY
PRECIPITATES             - RN, RDATE, PRECIPITATES
WIRELINE_LOGS            - RN, RDATE, LOG_TYPE, RUN_NUM
WATER_QUALITY_VARIABLES  - VARIABLE_NO

Once selected click on the button with a key symbol.  Small keys should appear beside the field names.
Click on the 'Save' button at the very top of the screen above the File tab to save the primary keys.
16. Once all of the primary keys are set up click on the Relationships button
17.Click 'Add' for each of the tables then 'Close'.  Note: if the 'Show Table' window doesn't appear click on the button with a "small yellow plus to the left of a table".
18. Arrange the tables so that registration is in the middle with all others around it.  click on RN in registration and drag to RN in another table.  In the window that pops up check the 'Enforce Referential Integrity' box then click 'Create'.  A line should now appear with a 1 near registration and infinity near the other table.  Repeat this for each table.
